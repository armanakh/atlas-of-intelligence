# First-Principles AI Curriculum v3.0.0

Release candidate for the curriculum dashboard and learning companion.

Mission: understand intelligence through mathematics, computation and engineering, beginning with machine learning.

## Contents
- `curriculum_registry.json`
- `dependency_registry.json`
- `learner_progress.json`
- `validation_report.json`
- `CODEX_HANDOFF.md`

## Core vocabulary
Track > Phase > Topic. Topics have learning objectives, prerequisites and related topics. Learner Progress, Confidence, pathway, priority and depth are separate dimensions.

## Important semantics
Prerequisite groups use OR between groups and AND within `requires_all`. Related Topics do not block readiness. Missing learner records mean unassessed. Phase placement is not a hard prerequisite gate. Stable IDs survive renames and moves.


## Release-candidate maturity
- Structural validation: passed for the checks listed in `validation_report.json`.
- Curriculum content: first-pass descriptions, learning targets and objectives; educational review continues.
- Learning material: exercises, curriculum projects and curated resources are not comprehensively authored.
- `content_draft` describes educational-content maturity, not structural validity.

## Optional content extensions
Each Topic has `exercise_ids`, `project_ids` and `learning_resource_ids` arrays. They are intentionally empty in this release candidate. Add separately identified Exercise, Project and LearningResource records later and link them by ID. Learner evidence is not interchangeable with a curriculum Project definition.

## Dependency validation clarification
All 334 active Topics have explicit first-pass dependency decisions. An empty `prerequisite_groups` array can represent a reviewed decision that no formal prerequisite is required; check `dependency_review_status`. The 227/107 figures appearing in an earlier draft are obsolete and do not apply to this package.
