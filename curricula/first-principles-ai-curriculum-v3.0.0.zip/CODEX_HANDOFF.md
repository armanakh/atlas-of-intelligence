# Codex implementation handoff
## First-Principles AI Curriculum v3.0.0

This is the curriculum release candidate. Implement the application against these data contracts; do not invent educational content or silently alter curriculum semantics.

## Package files
- `curriculum_registry.json`: 5 Tracks, 17 Phases, 334 stable Topics, learning targets, topic-specific objectives, pathway/priority/depth metadata, and migration ledger.
- `dependency_registry.json`: prerequisite groups and related-topic links.
- `learner_progress.json`: learner progress, confidence, evidence and unassessed policy.
- `validation_report.json`: release-candidate checks and known limitations.
- `README.md`: concise vocabulary and operating rules.

## Required semantics
1. Track, Phase and Topic are distinct entities. A Topic may be associated with multiple Tracks but has one current Phase placement.
2. Topic IDs are stable. Rename or move without changing ID. Retired IDs are never reused. Preserve migration aliases.
3. Prerequisite groups: OR between groups, AND within `requires_all`. An empty list means no formal prerequisite. Related-topic links are never blockers.
4. Phase placement is roadmap organization, not a hard lock. Readiness should be computed from actual prerequisite satisfaction.
5. Progress statuses are exactly `Not started`, `Learning`, `Practicing`, `Solid`, `Revisit`.
6. Confidence is an independent 1–5 scale; null means not assessed. Never derive one from the other.
7. Missing learner records mean unassessed, not `Not started`.
8. Curriculum definitions and learner records must remain separate.
9. Pathway (`core`, `supporting`, `optional`, `exploratory`), current priority (`high`, `medium_high`, `variable`), Progress, Confidence and depth are independent dimensions.
10. Preserve evidence provenance and progress scope. Do not infer mastery from a project or evidence label.
11. Support multiple prerequisite groups and multiple prerequisites per group.
12. Do not hard-code counts, IDs, phase order, or pathway distributions.

## Release-candidate validation
- 334 unique active Topics; 5 Tracks; 17 Phases.
- 334 Topics have explicit first-pass dependency decisions.
- 534 prerequisite edges; no unresolved refs, duplicate edges, self-dependencies, or cycles in the conservative union graph.
- Every Topic has three domain-specific observable learning objectives.
- 89 learner progress records retained; 245 Topics unassessed.
- Pathway and priority classifications are independent.

## Known limitations
Dependency decisions are model-assisted first-pass review, not external expert certification. Objectives are curriculum-level learning contracts, not full lesson plans or scored rubrics. Those are authored as individual Topics are taught. Preserve the ability to revise curriculum content without overwriting learner history.

## Suggested implementation sequence
1. Import and validate static curriculum data.
2. Implement learner-state separation and stable Topic references.
3. Implement dependency readiness with OR/AND prerequisite semantics.
4. Implement Track/Phase/Topic navigation and filtering.
5. Implement independent Progress, Confidence, pathway, priority and depth views.
6. Implement evidence links and history.
7. Add curriculum versioning/migration handling.
8. Test edge cases: no prerequisites, alternative routes, retired IDs, unassessed Topics, Revisit transitions, null confidence, and curriculum updates.


## Clarifications for import
### Dependency counts
The authoritative current figures are 334 active Topics, 334 explicit first-pass dependency decisions, 0 pending Topics, and 534 prerequisite edges. The earlier 227-reviewed/107-pending narrative was stale and is superseded. A reviewed empty prerequisite list means no formal prerequisite, not missing review. Use `dependency_review_status` to distinguish the two. First-pass review is not expert certification.

### Content maturity
`registry_status: content_draft` means educational content is at first-pass maturity. It does not mean the record or dependency graph failed structural validation. Keep structural validation, curriculum-content maturity and learning-material maturity as separate concepts.

### Exercises, projects and resources
Topic records include optional `exercise_ids`, `project_ids` and `learning_resource_ids` arrays. They are empty by design in v3.0.0. Future authored entities should have their own stable IDs and records, with Topic links stored by ID. Do not convert learner evidence into curriculum project definitions.

### Stable IDs, migrations and revision safety
- `id` is the durable Topic identity. Titles, descriptions, Phase placement, pathway, priority and objectives may change without changing the ID.
- The migration ledger records eight known retired IDs and their dispositions. It is not a complete event-sourced revision history. Preserve each retired ID and its disposition; never reactivate or reuse it. A migration may point to one destination or multiple destinations.
- `PROB-023` is reserved/unassigned, not an active Topic and not a retired alias. Do not create it implicitly.
- `converted_to_exercises` and `converted_to_integration_objective` describe conceptual disposition; they do not imply that populated Exercise records already exist.
- Keep curriculum versions and learner records separate. On future imports, match existing learner data by stable Topic ID, apply explicit migration rules, and never reset or infer progress/confidence because content or placement changed.
- Treat absent optional metadata as unknown/not supplied, not as a negative value. For the three new link arrays, an empty array means no current links.
- `schema_version` describes the data-contract revision; `curriculum_version` describes curriculum content. The `1.0.0-draft` schema label is not a statement that structural checks failed. Do not silently rewrite either version field.
